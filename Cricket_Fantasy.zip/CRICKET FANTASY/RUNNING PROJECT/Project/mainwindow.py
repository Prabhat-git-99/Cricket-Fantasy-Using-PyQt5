# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(895, 623)
        MainWindow.setStyleSheet("border:1px solid green;")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.horizontalLayout_8 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.batChoose = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setWeight(75)
        self.batChoose.setFont(font)
        self.batChoose.setObjectName("batChoose")
        self.horizontalLayout_6.addWidget(self.batChoose)
        self.wkChoose = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setWeight(75)
        self.wkChoose.setFont(font)
        self.wkChoose.setObjectName("wkChoose")
        self.horizontalLayout_6.addWidget(self.wkChoose)
        self.arChoose = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setWeight(75)
        self.arChoose.setFont(font)
        self.arChoose.setObjectName("arChoose")
        self.horizontalLayout_6.addWidget(self.arChoose)
        self.bowlChoose = QtWidgets.QRadioButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setBold(True)
        font.setWeight(75)
        self.bowlChoose.setFont(font)
        self.bowlChoose.setObjectName("bowlChoose")
        self.horizontalLayout_6.addWidget(self.bowlChoose)
        self.verticalLayout.addLayout(self.horizontalLayout_6)
        self.optionPlayer = QtWidgets.QListWidget(self.centralwidget)
        self.optionPlayer.setObjectName("optionPlayer")
        self.verticalLayout.addWidget(self.optionPlayer)
        self.horizontalLayout_8.addLayout(self.verticalLayout)
        spacerItem = QtWidgets.QSpacerItem(
            120, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_8.addItem(spacerItem)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout_7 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setMinimumSize(QtCore.QSize(81, 0))
        font = QtGui.QFont()
        font.setFamily("Comic Sans MS")
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.horizontalLayout_7.addWidget(self.label)
        self.teamName = QtWidgets.QLineEdit(self.centralwidget)
        self.teamName.setObjectName("teamName")
        self.horizontalLayout_7.addWidget(self.teamName)
        self.verticalLayout_2.addLayout(self.horizontalLayout_7)
        self.fillPlayer = QtWidgets.QListWidget(self.centralwidget)
        self.fillPlayer.setObjectName("fillPlayer")
        self.verticalLayout_2.addWidget(self.fillPlayer)
        self.horizontalLayout_8.addLayout(self.verticalLayout_2)
        self.horizontalLayout_8.setStretch(0, 100)
        self.horizontalLayout_8.setStretch(2, 100)
        self.gridLayout.addLayout(self.horizontalLayout_8, 7, 0, 1, 1)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.pointsAvailable = QtWidgets.QLineEdit(self.centralwidget)
        self.pointsAvailable.setMaximumSize(QtCore.QSize(51, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.pointsAvailable.setFont(font)
        self.pointsAvailable.setText("")
        self.pointsAvailable.setObjectName("pointsAvailable")
        self.horizontalLayout.addWidget(self.pointsAvailable)
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:green;")
        self.label_3.setObjectName("label_3")
        self.horizontalLayout.addWidget(self.label_3)
        self.horizontalLayout_20 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_20.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_20.setObjectName("horizontalLayout_20")
        self.horizontalLayout.addLayout(self.horizontalLayout_20)
        spacerItem1 = QtWidgets.QSpacerItem(
            198, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.horizontalLayout_19 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_19.setObjectName("horizontalLayout_19")
        self.pointsUsed = QtWidgets.QLineEdit(self.centralwidget)
        self.pointsUsed.setMaximumSize(QtCore.QSize(51, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.pointsUsed.setFont(font)
        self.pointsUsed.setText("")
        self.pointsUsed.setObjectName("pointsUsed")
        self.horizontalLayout_19.addWidget(self.pointsUsed)
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("color:red;")
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_19.addWidget(self.label_2)
        self.horizontalLayout.addLayout(self.horizontalLayout_19)
        self.gridLayout.addLayout(self.horizontalLayout, 4, 0, 1, 1)
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_9.setFont(font)
        self.label_9.setStyleSheet("background-color:blue;color:white;")
        self.label_9.setAlignment(QtCore.Qt.AlignCenter)
        self.label_9.setObjectName("label_9")
        self.gridLayout.addWidget(self.label_9, 1, 0, 1, 1)
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.gridLayout.addWidget(self.frame_2, 5, 0, 1, 1)
        self.horizontalLayout_10 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_10.setObjectName("horizontalLayout_10")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_14 = QtWidgets.QLabel(self.centralwidget)
        self.label_14.setMaximumSize(QtCore.QSize(71, 16777215))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.label_14.setFont(font)
        self.label_14.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label_14.setObjectName("label_14")
        self.horizontalLayout_2.addWidget(self.label_14)
        self.totalBat = QtWidgets.QLineEdit(self.centralwidget)
        self.totalBat.setMaximumSize(QtCore.QSize(41, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.totalBat.setFont(font)
        self.totalBat.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.totalBat.setText("")
        self.totalBat.setObjectName("totalBat")
        self.horizontalLayout_2.addWidget(self.totalBat)
        spacerItem2 = QtWidgets.QSpacerItem(
            17, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem2)
        self.horizontalLayout_10.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_18 = QtWidgets.QLabel(self.centralwidget)
        self.label_18.setMaximumSize(QtCore.QSize(71, 16777215))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.label_18.setFont(font)
        self.label_18.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label_18.setObjectName("label_18")
        self.horizontalLayout_3.addWidget(self.label_18)
        self.totalBowl = QtWidgets.QLineEdit(self.centralwidget)
        self.totalBowl.setMaximumSize(QtCore.QSize(41, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.totalBowl.setFont(font)
        self.totalBowl.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.totalBowl.setText("")
        self.totalBowl.setObjectName("totalBowl")
        self.horizontalLayout_3.addWidget(self.totalBowl)
        spacerItem3 = QtWidgets.QSpacerItem(
            17, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem3)
        self.horizontalLayout_10.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.labelAll = QtWidgets.QLabel(self.centralwidget)
        self.labelAll.setMaximumSize(QtCore.QSize(71, 16777215))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.labelAll.setFont(font)
        self.labelAll.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.labelAll.setObjectName("labelAll")
        self.horizontalLayout_4.addWidget(self.labelAll)
        self.totalAll = QtWidgets.QLineEdit(self.centralwidget)
        self.totalAll.setMaximumSize(QtCore.QSize(41, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.totalAll.setFont(font)
        self.totalAll.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.totalAll.setText("")
        self.totalAll.setObjectName("totalAll")
        self.horizontalLayout_4.addWidget(self.totalAll)
        spacerItem4 = QtWidgets.QSpacerItem(
            17, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_4.addItem(spacerItem4)
        self.horizontalLayout_10.addLayout(self.horizontalLayout_4)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.label_20 = QtWidgets.QLabel(self.centralwidget)
        self.label_20.setMaximumSize(QtCore.QSize(26, 16777215))
        font = QtGui.QFont()
        font.setPointSize(8)
        font.setBold(True)
        font.setWeight(75)
        self.label_20.setFont(font)
        self.label_20.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.label_20.setObjectName("label_20")
        self.horizontalLayout_5.addWidget(self.label_20)
        self.totalWk = QtWidgets.QLineEdit(self.centralwidget)
        self.totalWk.setMaximumSize(QtCore.QSize(41, 16777215))
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(9)
        font.setBold(True)
        font.setItalic(True)
        font.setWeight(75)
        self.totalWk.setFont(font)
        self.totalWk.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.totalWk.setText("")
        self.totalWk.setObjectName("totalWk")
        self.horizontalLayout_5.addWidget(self.totalWk)
        spacerItem5 = QtWidgets.QSpacerItem(
            17, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem5)
        self.horizontalLayout_10.addLayout(self.horizontalLayout_5)
        self.gridLayout.addLayout(self.horizontalLayout_10, 2, 0, 1, 1)
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.gridLayout.addWidget(self.frame, 6, 0, 1, 1)
        self.frame_21 = QtWidgets.QFrame(self.centralwidget)
        self.frame_21.setObjectName("frame_21")
        self.gridLayout.addWidget(self.frame_21, 3, 0, 1, 1)
        self.frame1 = QtWidgets.QFrame(self.centralwidget)
        self.frame1.setMinimumSize(QtCore.QSize(0, 10))
        self.frame1.setObjectName("frame1")
        self.gridLayout.addWidget(self.frame1, 0, 0, 1, 1)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 895, 36))
        self.menubar.setStyleSheet(
            "background-color:green; color:white;font-size:20px;")
        self.menubar.setObjectName("menubar")
        self.menuMANAGE_Team = QtWidgets.QMenu(self.menubar)
        self.menuMANAGE_Team.setStyleSheet("background-color:orange;")
        self.menuMANAGE_Team.setObjectName("menuMANAGE_Team")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setStyleSheet("background-color:green;")
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionNEW_Team = QtWidgets.QAction(MainWindow)
        self.actionNEW_Team.setObjectName("actionNEW_Team")
        self.actionOPEN_Team = QtWidgets.QAction(MainWindow)
        self.actionOPEN_Team.setObjectName("actionOPEN_Team")
        self.actionSAVE_Team = QtWidgets.QAction(MainWindow)
        self.actionSAVE_Team.setObjectName("actionSAVE_Team")
        self.actionEVALUATE_Team = QtWidgets.QAction(MainWindow)
        self.actionEVALUATE_Team.setObjectName("actionEVALUATE_Team")
        self.menuMANAGE_Team.addAction(self.actionNEW_Team)
        self.menuMANAGE_Team.addSeparator()
        self.menuMANAGE_Team.addAction(self.actionOPEN_Team)
        self.menuMANAGE_Team.addSeparator()
        self.menuMANAGE_Team.addAction(self.actionSAVE_Team)
        self.menuMANAGE_Team.addSeparator()
        self.menuMANAGE_Team.addAction(self.actionEVALUATE_Team)
        self.menubar.addAction(self.menuMANAGE_Team.menuAction())
        self.optionPlayer.itemDoubleClicked.connect(self.sendToFill)
        self.fillPlayer.itemDoubleClicked.connect(self.sendToOption)
        self.batChoose.toggled.connect(self.ctg)
        self.bowlChoose.toggled.connect(self.ctg)
        self.arChoose.toggled.connect(self.ctg)
        self.wkChoose.toggled.connect(self.ctg)
        self.menuMANAGE_Team.triggered[QtWidgets.QAction].connect(self.menu)
        self.bat = 0
        self.ar = 0
        self.wk = 0
        self.bwl = 0
        self.avl = 1000
        self.used = 0
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.batChoose.setText(_translate("MainWindow", "BAT"))
        self.wkChoose.setText(_translate("MainWindow", "WK"))
        self.arChoose.setText(_translate("MainWindow", "AR"))
        self.bowlChoose.setText(_translate("MainWindow", "BOWL"))
        self.label.setText(_translate("MainWindow", "Team Name:"))
        self.label_3.setText(_translate("MainWindow", "Points Available"))
        self.label_2.setText(_translate("MainWindow", "Points Used"))
        self.label_9.setText(_translate("MainWindow", "Your Selection"))
        self.label_14.setText(_translate("MainWindow", "Batsman:"))
        self.label_18.setText(_translate("MainWindow", "Bowler:"))
        self.labelAll.setText(_translate("MainWindow", "AllRounder:"))
        self.label_20.setText(_translate("MainWindow", "WK:"))
        self.menuMANAGE_Team.setTitle(_translate("MainWindow", "MANAGE Team"))
        self.actionNEW_Team.setText(_translate("MainWindow", "NEW Team"))
        self.actionOPEN_Team.setText(_translate("MainWindow", "OPEN Team"))
        self.actionSAVE_Team.setText(_translate("MainWindow", "SAVE Team"))
        self.actionEVALUATE_Team.setText(
            _translate("MainWindow", "EVALUATE Team"))

    #############################################################################################
    ##############----------CONSTRAINTS AND POINT AWARD--------------############################
    def criteria(self, ctgr, item):
        msg = ''
        if ctgr == "BAT" and self.bat >= 5:
            msg = "5 Batsman Allowed"
        if ctgr == "WK" and self.wk >= 1:
            msg = "1 WicketKeeper Allowed"
        if ctgr == "BWL" and self.bwl >= 5:
            msg = "5 Bowlers Allowed"
        if ctgr == "AR" and self.ar >= 3:
            msg = "3 Allrounders Allowed"
        if msg != '':
            self.alertMsg(msg)
            return False

        if self.avl <= 0:
            msg = "No More Points Remained!"
            self.alertMsg(msg)
            return False

        if ctgr == "BAT":
            self.bat += 1
        if ctgr == "WK":
            self.wk += 1
        if ctgr == "BWL":
            self.bwl += 1
        if ctgr == "AR":
            self.ar += 1

        sql = "SELECT value from stats where player='"+item.text()+"'"
        cur = conn.execute(sql)
        row = cur.fetchone()
        self.avl -= int(row[0])
        self.used += int(row[0])
        return True

    #####################################################################################
    #############################--------MENU--------####################################

    def menu(self, action):
        txt = (action.text())

        if txt == 'NEW Team':
            self.bat = 0
            self.wk = 0
            self.bwl = 0
            self.ar = 0
            self.avl = 1000
            self.used = 0
            self.optionPlayer.clear()
            self.fillPlayer.clear()

            text, ok = QtWidgets.QInputDialog.getText(
                MainWindow, "Team", "Enter name of team:")
            if ok:
                self.teamName.setText(str(text))

            self.show()

        if txt == 'SAVE Team':
            count = self.fillPlayer.count()
            choosed = ""
            for i in range(count):
                choosed += self.fillPlayer.item(i).text()
                if i < count-1:
                    choosed += ","
            self.saveteam(self.teamName.text(), choosed, self.used)

        if txt == 'OPEN Team':
            self.bat = 0
            self.bwl = 0
            self.ar = 0
            self.wk = 0
            self.avl = 1000
            self.used = 0
            self.optionPlayer.clear()
            self.fillPlayer.clear()
            self.show()
            self.openteam()

        if txt == 'EVALUATE Team':
            from evaluatewindow import Ui_evaluateWindow
            self.window = QtWidgets.QMainWindow()
            self.ui = Ui_evaluateWindow()
            self.ui.setupUi(self.window)
            self.window.show()

    #################################################################################################
    #############-------SEND PLAYER TO THE SELECTION LIST------------################################
    def sendToFill(self, item):

        ctgr = ''
        if self.batChoose.isChecked() == True:
            ctgr = 'BAT'
        if self.wkChoose.isChecked() == True:
            ctgr = 'WK'
        if self.bowlChoose.isChecked() == True:
            ctgr = 'BWL'
        if self.arChoose.isChecked() == True:
            ctgr = 'AR'
        ret = self.criteria(ctgr, item)

        if ret == True:
            self.optionPlayer.takeItem(self.optionPlayer.row(item))

            self.fillPlayer.addItem(item.text())
            self.show()

    #############################################################################################
    #############---------SHOW No. PLAAYER IN CATEGORY-----------################################
    def show(self):
        self.totalBat.setText(str(self.bat))
        self.totalBowl.setText(str(self.bwl))
        self.totalWk.setText(str(self.wk))
        self.totalAll.setText(str(self.ar))
        self.pointsAvailable.setText(str(self.avl))
        self.pointsUsed.setText(str(self.used))

    #################################################################################################
    ###################--------ASSIGNING CATEGORY TO RADIO BUTTON------------########################
    def ctg(self):
        ctgr = ''
        if self.batChoose.isChecked() == True:
            ctgr = 'BAT'
        if self.bowlChoose.isChecked() == True:
            ctgr = 'BWL'
        if self.arChoose.isChecked() == True:
            ctgr = 'AR'
        if self.wkChoose.isChecked() == True:
            ctgr = 'WK'

        self.categroyPlayer(ctgr)

    #################################################################################################
    ##################-----------REMOVE FROM SELECTED PLAYERS------------############################
    def sendToOption(self, item):
        self.fillPlayer.takeItem(self.fillPlayer.row(item))

        cursor = conn.execute(
            "SELECT player,value, ctg from stats where player='"+item.text()+"'")
        row = cursor.fetchone()
        self.avl = self.avl+int(row[1])
        self.used = self.used-int(row[1])
        ctgr = row[2]
        if ctgr == "BAT":
            self.bat -= 1
            if self.batChoose.isChecked() == True:
                self.optionPlayer.addItem(item.text())
        if ctgr == "BWL":
            self.bwl -= 1
            if self.bowlChoose.isChecked() == True:
                self.optionPlayer.addItem(item.text())
        if ctgr == "AR":
            self.ar -= 1
            if self.arChoose.isChecked() == True:
                self.optionPlayer.addItem(item.text())
        if ctgr == "WK":
            self.wk -= 1
            if self.wkChoose.isChecked() == True:
                self.optionPlayer.addItem(item.text())
        self.show()

    #####################################################################################
    ##########------------SHOWING CATEGORY WISE PLAYER------------#######################
    def categroyPlayer(self, ctgr):
        if self.teamName.text() == '':
            self.alertMsg("Enter name of team")
            return

        self.optionPlayer.clear()
        sql = "SELECT player from players where ctg='"+ctgr+"';"
        cur = conn.execute(sql)
        for row in cur:
            choosed = []
            for i in range(self.fillPlayer.count()):
                choosed.append(self.fillPlayer.item(i).text())
            if row[0] not in choosed:
                self.optionPlayer.addItem(row[0])

    #####################################################################################
    #################--------------OPEN TEAM-------------################################
    def openteam(self):
        sql = "select name from teams;"
        cur = conn.execute(sql)
        teams = []
        for row in cur:
            teams.append(row[0])
        team, ok = QtWidgets.QInputDialog.getItem(
            MainWindow, "Dream", "Choose A Team", teams, 0, False)
        if ok and team:
            self.teamName.setText(team)
        sql1 = "SELECT players,value from teams where name='"+team+"';"
        cur = conn.execute(sql1)
        row = cur.fetchone()
        choosed = row[0].split(',')
        self.fillPlayer.addItems(choosed)
        self.used = row[1]
        self.avl = 1000-row[1]
        count = self.fillPlayer.count()
        for i in range(count-1):
            ply = self.fillPlayer.item(i).text()
            sql = "select ctg from stats where player='"+ply+"';"
            cur = conn.execute(sql)
            row = cur.fetchone()
            ctgr = row[0]
            if ctgr == "BAT":
                self.bat += 1
            if ctgr == "BWL":
                self.bwl += 1
            if ctgr == "AR":
                self.ar += 1
            if ctgr == "WK":
                self.wk += 1

        self.show()

    #########################################################################################
    ##############------------SAVE INTO DATABASE ON SAVE CLICK------#########################
    def saveteam(self, nm, ply, val):

        if self.bat+self.bwl+self.ar+self.wk != 11:
            self.alertMsg("Please Select 11 Players!")
            return

        sql = "INSERT INTO teams (name,players,value) VALUES ('" + \
            nm+"','"+ply+"','"+str(val)+"');"
        try:
            cur = conn.execute(sql)
            self.alertMsg("Team Saved Succesfully")
            conn.commit()
        except:
            self.alertMsg("Error in Operation")
            conn.rollback()

    #############################################################################
    ############-----MSG ON WRONG CHOICE--------#################################
    def alertMsg(self, msg):
        Dialog = QtWidgets.QMessageBox()
        Dialog.setText(msg)
        Dialog.setWindowTitle("Hello Selector")
        ret = Dialog.exec()


if __name__ == "__main__":
    import sqlite3
    conn = sqlite3.connect('database.db')
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
