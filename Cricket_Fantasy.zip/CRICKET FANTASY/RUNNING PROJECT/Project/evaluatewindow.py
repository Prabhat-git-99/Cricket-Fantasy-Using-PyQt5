# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'evaluatewindow.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_evaluateWindow(object):
    def setupUi(self, evaluateWindow):
        evaluateWindow.setObjectName("evaluateWindow")
        evaluateWindow.resize(791, 657)
        evaluateWindow.setStyleSheet(
            "background-color:pink;border:1px solid green;")
        self.centralwidget = QtWidgets.QWidget(evaluateWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.gridLayout = QtWidgets.QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Yu Gothic UI")
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("background-color:blue; color:white;")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.gridLayout.addWidget(self.frame, 1, 0, 1, 1)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setMaximumSize(QtCore.QSize(71, 16777215))
        font = QtGui.QFont()
        font.setFamily("Yu Gothic UI")
        font.setPointSize(-1)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setStyleSheet("color:darkblue;font-size:13px;")
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.horizontalLayout_3.addLayout(self.horizontalLayout)
        self.selectTeam = QtWidgets.QComboBox(self.centralwidget)
        self.selectTeam.setMinimumSize(QtCore.QSize(60, 18))
        self.selectTeam.setStyleSheet("border:0;background:lightblue")
        self.selectTeam.setObjectName("selectTeam")
        import sqlite3
        conn = sqlite3.connect('database.db')
        self.horizontalLayout.addWidget(self.selectTeam)
        sql = "select name from teams"
        cur = conn.execute(sql)
        teams = []
        for row in cur:
            self.selectTeam.addItem(row[0])
        conn.close()
        self.horizontalLayout_3.addWidget(self.selectTeam)
        spacerItem = QtWidgets.QSpacerItem(
            158, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setMaximumSize(QtCore.QSize(91, 16777215))
        font = QtGui.QFont()
        font.setFamily("Yu Gothic")
        font.setPointSize(-1)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:darkblue;font-size:14px;")
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_2.addWidget(self.label_3)
        self.selectMatch = QtWidgets.QComboBox(self.centralwidget)
        self.selectMatch.setMinimumSize(QtCore.QSize(60, 18))
        self.selectMatch.setStyleSheet("border:0;background:lightblue")
        self.selectMatch.setObjectName("selectMatch")
        self.selectMatch.addItem("")
        self.horizontalLayout_2.addWidget(self.selectMatch)
        self.horizontalLayout_3.addLayout(self.horizontalLayout_2)
        self.gridLayout.addLayout(self.horizontalLayout_3, 2, 0, 1, 1)
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setStyleSheet("background-color:lightgrey;")
        self.groupBox.setTitle("")
        self.groupBox.setObjectName("groupBox")
        self.gridLayout.addWidget(self.groupBox, 3, 0, 1, 1)
        self.frame_3 = QtWidgets.QFrame(self.centralwidget)
        self.frame_3.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_3.setObjectName("frame_3")
        self.gridLayout.addWidget(self.frame_3, 4, 0, 1, 1)
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.gridLayout.addWidget(self.frame_2, 5, 0, 1, 1)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Yu Gothic UI")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setStyleSheet("")
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.verticalLayout.addWidget(self.label_4)
        self.listWidget = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget.setStyleSheet("background-color:lightblue")
        self.listWidget.setObjectName("listWidget")
        self.verticalLayout.addWidget(self.listWidget)
        self.horizontalLayout_5.addLayout(self.verticalLayout)
        spacerItem1 = QtWidgets.QSpacerItem(
            198, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setMaximumSize(QtCore.QSize(71, 16777215))
        font = QtGui.QFont()
        font.setFamily("Yu Gothic UI")
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("")
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_4.addWidget(self.label_5)
        self.points = QtWidgets.QLineEdit(self.centralwidget)
        self.points.setMinimumSize(QtCore.QSize(71, 22))
        self.points.setMaximumSize(QtCore.QSize(71, 16777215))
        self.points.setStyleSheet("background:yellow;color:black;")
        self.points.setObjectName("points")
        self.horizontalLayout_4.addWidget(self.points)
        self.verticalLayout_2.addLayout(self.horizontalLayout_4)
        self.listWidget_2 = QtWidgets.QListWidget(self.centralwidget)
        self.listWidget_2.setStyleSheet("background-color:lightblue")
        self.listWidget_2.setObjectName("listWidget_2")
        self.verticalLayout_2.addWidget(self.listWidget_2)
        self.horizontalLayout_5.addLayout(self.verticalLayout_2)
        self.gridLayout.addLayout(self.horizontalLayout_5, 6, 0, 1, 1)
        self.calculateScore = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Yu Gothic UI")
        font.setPointSize(11)
        font.setBold(True)
        font.setWeight(75)
        self.calculateScore.setFont(font)
        self.calculateScore.setStyleSheet(
            "color:blue;text-transform:uppercase;border:0;background-color:lightgreen")
        self.calculateScore.setObjectName("calculateScore")
        self.calculateScore.clicked.connect(self.calculate)
        self.gridLayout.addWidget(self.calculateScore, 7, 0, 1, 1)
        evaluateWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(evaluateWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 791, 28))
        self.menubar.setObjectName("menubar")
        evaluateWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(evaluateWindow)
        self.statusbar.setObjectName("statusbar")
        evaluateWindow.setStatusBar(self.statusbar)

        self.retranslateUi(evaluateWindow)
        QtCore.QMetaObject.connectSlotsByName(evaluateWindow)

    def calculate(self):
        import sqlite3
        conn = sqlite3.connect('database.db')
        team = self.selectTeam.currentText()
        self.listWidget.clear()
        sql1 = "select players, value from teams where name='"+team+"'"
        cur = conn.execute(sql1)
        row = cur.fetchone()
        selected = row[0].split(',')
        self.listWidget.addItems(selected)
        teamttl = 0
        self.listWidget_2.clear()
        match = self.selectMatch.currentText()
        for i in range(self.listWidget.count()):
            ttl, batscore, bowlscore, fieldscore = 0, 0, 0, 0
            nm = self.listWidget.item(i).text()
            cursor = conn.execute("select * from "+match +
                                  " where player='"+nm+"'")
            row = cursor.fetchone()
            batscore = int(row[1]/2)
            if batscore >= 50:
                batscore += 5
            if batscore >= 100:
                batscore += 10
            if row[1] > 0:
                sr = row[1]/row[2]
                if sr >= 80 and sr < 100:
                    batscore += 2
                if sr >= 100:
                    batscore += 4
            batscore = batscore+row[3]
            batscore = batscore+2*row[4]
            bowlscore = row[8]*10
            if row[8] >= 3:
                bowlscore = bowlscore+5
            if row[8] >= 5:
                bowlscore = bowlscore = bowlscore+10
            if row[7] > 0:
                er = 6*row[7]/row[5]
                if er <= 2:
                    bowlscore = bowlscore+10
                if er > 2 and er <= 3.5:
                    bowlscore = bowlscore+7
                if er > 3.5 and er <= 4.5:
                    bowlscore = bowlscore+4
            fieldscore = (row[9]+row[10]+row[11])*10
            ttl = batscore+bowlscore+fieldscore
            self.listWidget_2.addItem(str(ttl))
            teamttl = teamttl+ttl

        self.points.setText(str(teamttl))

    def retranslateUi(self, evaluateWindow):
        _translate = QtCore.QCoreApplication.translate
        evaluateWindow.setWindowTitle(
            _translate("evaluateWindow", "evaluateWindow"))
        self.label.setText(_translate(
            "evaluateWindow", "Evaluate The Performance of your Fantasy Team"))
        self.label_2.setText(_translate("evaluateWindow", "Select Team"))
        self.label_3.setText(_translate("evaluateWindow", "Select Match"))
        self.label_4.setText(_translate("evaluateWindow", "Players"))
        self.label_5.setText(_translate("evaluateWindow", "Points"))
        self.calculateScore.setText(_translate(
            "evaluateWindow", "Calculate Score"))
        self.selectMatch.setItemText(0, _translate("Dialog", "Match1"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    evaluateWindow = QtWidgets.QMainWindow()
    ui = Ui_evaluateWindow()
    ui.setupUi(evaluateWindow)
    evaluateWindow.show()
    sys.exit(app.exec_())
